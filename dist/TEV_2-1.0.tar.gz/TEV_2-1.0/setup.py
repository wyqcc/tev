#coding: utf-8
from setuptools import setup
setup(name='TEV_2',
      version='1.0',
      py_modules=['TEV_2'],
      )